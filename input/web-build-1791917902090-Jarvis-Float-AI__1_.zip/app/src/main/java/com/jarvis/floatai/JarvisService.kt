package com.jarvis.floatai

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.TextView
import java.util.*

class JarvisService : Service(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var wm: WindowManager
    private var bubble: View? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)

        val channel = NotificationChannel(
            "jarvis",
            "Jarvis Assistant",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val notification = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is running")
            .setContentText("Floating assistant is active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

        startForeground(1001, notification)
        showBubble()
    }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = "J"
            textSize = 22f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(37, 99, 235))
            gravity = Gravity.CENTER
            setPadding(22, 16, 22, 16)
            setOnClickListener {
                speak("I'm listening. Say your command.")
            }
        }

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            120, 120, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 30
            y = 250
        }

        wm.addView(bubble, params)
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
        }
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
