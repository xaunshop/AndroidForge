package com.jarvis.floatai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private val requestCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Jarvis Float AI"
            textSize = 28f
            setPadding(0, 0, 0, 20)
        }

        val info = TextView(this).apply {
            text = "Floating voice assistant for Android.\n\n1. Allow microphone access.\n2. Allow display over other apps.\n3. Start Jarvis.\n\nThe AI key is entered separately and is never hard-coded into this project."
            textSize = 16f
        }

        val overlay = Button(this).apply {
            text = "Allow Floating Overlay"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }

        val mic = Button(this).apply {
            text = "Allow Microphone"
            setOnClickListener {
                ActivityCompat.requestPermissions(
                    this@MainActivity,
                    arrayOf(Manifest.permission.RECORD_AUDIO),
                    requestCode
                )
            }
        }

        val start = Button(this).apply {
            text = "Start Jarvis"
            setOnClickListener {
                startForegroundService(Intent(this@MainActivity, JarvisService::class.java))
                Toast.makeText(this, "Jarvis service started", Toast.LENGTH_SHORT).show()
            }
        }

        val stop = Button(this).apply {
            text = "Stop Jarvis"
            setOnClickListener {
                stopService(Intent(this@MainActivity, JarvisService::class.java))
            }
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(overlay)
        layout.addView(mic)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }
}
