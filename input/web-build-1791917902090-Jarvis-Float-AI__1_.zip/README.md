# Jarvis Float AI

A starter Android floating assistant project.

## Current features
- Floating Jarvis bubble
- Android foreground service
- Text-to-speech
- Microphone permission setup
- Overlay permission setup
- GitHub Actions workflow that builds a debug APK

## Important
The Gemini API key is intentionally NOT included in the APK source. A later version should use a secure backend or user-entered key.

The always-listening "Hey Jarvis" wake word requires additional Android-compatible wake-word handling and must comply with Android background microphone restrictions.
